"""Toutes les constantes nécessaires au projet"""
from PyQt5.QtCore import QRegExp, Qt
from PyQt5.QtGui import QColor
from addon_marked_tiles_gaspard import special

N_LIGNES = 10
TAILLE_POLICE = 11
MANA = 5
VIE_MAX = 15
FICHIER_NIVEAUX = "fichier_niveaux.txt"
FICHIER_UTILISATEUR = "fichier_utilisateur.py"
FICHIER_CODEX = "fichier_codex.txt"
BLACKLIST = [QRegExp("(\\b|_)import(\\b|_)"), QRegExp("\\bexec *\\("), QRegExp("\\beval *\\(")]
GRID_WIDTH = 80
GRID_HEIGHT = 80
VIEWPORT_WIDTH = 20
VIEWPORT_HEIGHT = 10
TILE_SIZE = [32, 32]
LISTE_SPECIAL_ACTION = [2, 3, 4, 5, 6, 7, 8, 9, 10]
WIDTH, HEIGHT = VIEWPORT_WIDTH * TILE_SIZE[0], VIEWPORT_HEIGHT * TILE_SIZE[1]

RESTRICTED_TILES = special(GRID_WIDTH, GRID_HEIGHT)
ORIGIN_PLAYER = [0, 0]
ORIGIN_MAP = [0, 0]

ROUGE_FONCE = QColor(144, 12, 40)
CYAN = QColor(28, 195, 173)
VIOLET = QColor(141, 29, 117)
GRIS = QColor(153, 153, 153)
BLEU_FONCE = QColor(38, 21, 232)
VERT = QColor(0, 197, 6)
DORE = QColor(232, 171, 29)
ORANGE = QColor(210, 100, 40)
VERT_POMME = QColor(37, 142, 0)
COULEURS = {"rouge_fonce" : ROUGE_FONCE, "cyan" : CYAN, "violet" : VIOLET, "gris" : GRIS, "bleu_fonce" : BLEU_FONCE,
            "vert" : VERT, "dore" : DORE, "orange" : ORANGE, "vert_pomme" : VERT_POMME}
HIGHLIGHTING_RULES : tuple[tuple[QRegExp, QColor, bool]] = (
                      (QRegExp("\\bfor\\b"), "rouge_fonce", True),
                      (QRegExp("\\bwhile\\b"), "rouge_fonce", True),
                      (QRegExp("\\bin\\b"), "rouge_fonce", True),
                      (QRegExp("\\bdef\\b"), "bleu_fonce", True),
                      (QRegExp("\\bclass\\b"), "bleu_fonce", True),
                      (QRegExp("\\bif\\b"), "rouge_fonce", True),
                      (QRegExp("\\belif\\b"), "rouge_fonce", True),
                      (QRegExp("\\belse\\b"), "rouge_fonce", True),
                      (QRegExp("\\band\\b"), "vert", True),
                      (QRegExp("\\bor\\b"), "vert", True),
                      (QRegExp("\\bnot\\b"), "vert", True),
                      (QRegExp("\\brange\\b"), "cyan", False),
                      (QRegExp("\\bprint\\b"), "cyan", False),
                      (QRegExp("\\bsplit\\b"), "cyan", False),
                      (QRegExp("\\binsert\\b"), "cyan", False),
                      (QRegExp("\\bcount\\b"), "cyan", False),
                      (QRegExp("\\bremove\\b"), "cyan", False),
                      (QRegExp("\\bNone\\b"), "violet", False),
                      (QRegExp("\\bTrue\\b"), "violet", False),
                      (QRegExp("\\bFalse\\b"), "violet", False),
                      (QRegExp("=|-|\*|\+|/|%"), "violet", False),
                      (QRegExp("[0-9]+"), "dore", False),
                      (QRegExp("=="), "vert", False),
                      (QRegExp("<="), "vert", False),
                      (QRegExp(">="), "vert", False),
                      (QRegExp(">"), "vert", False),
                      (QRegExp("<"), "vert", False),
                      (QRegExp("!="), "vert", False),
                      (QRegExp("\[|\]|\(|\)|\{|\}"), "vert_pomme", False),
                      (QRegExp("#[^\\n]*"),"gris", False),
                      (QRegExp("\"[^\"]*\""), "orange", False)
                      )

MOVES ={Qt.Key_Up : (0, -1), Qt.Key_Down : (0, 1), Qt.Key_Left : (-1, 0), Qt.Key_Right : (1, 0)}