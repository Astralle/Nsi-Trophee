"""Toutes les fonctions n'ayant pas de liens avec l'interface et pouvant être utilisé n'importe où.
Ne pose aucun problème d'importation dans les autres fichiers expecté dans les fichiers
'constantes' et 'addon_marked_tiles_gaspard'
"""
from constantes import *

def is_legal(texte : str) -> bool :
    """Renvoie si l'utilisateur a ou non respecté les restrictions que lui sont imposées.

    Args:
        texte (str): Le code de l'utilisateur

    Returns:
        bool : Si le code de l'utilisateur respecte les restrictions ou non
    """
    for interdit in BLACKLIST :
        if interdit.indexIn(texte) != -1:
            print("NON")
            return False
    return True

def is_exist(iterable, index: int, *tests : str) -> bool :
    """Regarde si iterable[index] existe et s'il est un des strings tests

    Args:
        iterable (liste/tuple/iterable): la liste itérable
        index (int): l'indice
        *tests (str): Les différentes valeurs de iterable[index] possible

    Returns:
        bool: iterable[index] in test
    """
    if index < 0 :
        if -len(iterable) <= index:
            return iterable[index] in tests
    else :
        if len(iterable) > index:
            return iterable[index] in tests
    return False

def can_move_to(position : tuple[int,int]) -> bool :
    """
    check if the position is not marked on the grid as 1 and so if the player can move to that position
    :param position: the position to test
    :return: a boolean indicating whether the position is marked or not
    """
    alpha, beta = position
    blocked_case = (0 <= alpha < GRID_WIDTH and 0 <= beta < GRID_HEIGHT and RESTRICTED_TILES[beta][alpha] != -1)
    if not blocked_case:
        print("Player tried to move to a blocked tile " + str(position))
    return blocked_case