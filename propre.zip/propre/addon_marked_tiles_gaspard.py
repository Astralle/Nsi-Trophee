"""
This library is used to decongest pygame_game_script.py ,
It is a list of all marked tiles with their respective code
"""


def special(grid_width, grid_height):
    """
    Make some tiles do certain action:

    0 (not calling the tiles) : You can move freely on the tile
    -1 : You cannot on move freely on the tile
    1 or more: the number of the level present on the case

    :param grid_width: width of the 2D plane
    :param grid_height: height of the 2D plane
    :return: a 2D plane with special action applied
    """
    marked_tiles = [[0] * grid_width for _ in range(grid_height)]
    marked_tiles[0][0] = 1
    marked_tiles[1][1] = -1
    marked_tiles[2][2] = 2

    return marked_tiles
