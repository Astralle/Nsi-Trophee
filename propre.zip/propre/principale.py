"""Programme principale, celui qui sera exécuter."""
from constantes import *
from fonctions_liens import *
from interface_pyqt5 import creer_interface
from PyQt5.QtGui import QPixmap, QKeyEvent, QPainter
from PyQt5.QtWidgets import QWidget
from PyQt5.QtCore import QRectF
from fonctions_globales import *

background_position = ORIGIN_MAP
player_pos = ORIGIN_PLAYER


def executer(zone_texte : QTextEdit) -> None :
    """Exécute le code écrit par l'utilisateur

    Args :
        zone_texte (QTextEdit) : La zone d'édition où l'utilisateur a écrit du code
    """
    texte = zone_texte.toPlainText()
    if is_legal(texte) :
        """with open(FICHIER_UTILISATEUR, "w", encoding='utf-8') as fichier :
            fichier.write(texte)"""
        exec(texte)

def redessiner(jeu : QWidget, images : dict) -> None :
    """Gère l'affichage de la map et du personnage
    
    Args :
        jeu (QWidget) : La zone du jeu
        images (dict[str : QPixmap]) : Le dictionnaire contenant les QPixmap du background et du player
    """
    jeu.setFixedHeight(int(jeu.width()*VIEWPORT_HEIGHT/VIEWPORT_WIDTH))
    width = VIEWPORT_WIDTH * TILE_SIZE[0]
    height = VIEWPORT_HEIGHT * TILE_SIZE[1]
    taille = jeu.width()
    ratio = height/width
    targets["background"] = QRectF(0, 0, taille, ratio * taille)
    sources["background"] = QRectF(background_position[0] * width, background_position[1]*height, width, height)
    targets["player"] = QRectF((player_pos[0]%VIEWPORT_WIDTH)*(taille/VIEWPORT_WIDTH), (player_pos[1]%VIEWPORT_HEIGHT)*(taille*ratio/VIEWPORT_HEIGHT), taille/VIEWPORT_WIDTH, (taille/VIEWPORT_WIDTH)*images["player"].height()/images["player"].width())
    sources["player"] = QRectF(0.0, 0.0, images["player"].width(), images["player"].height())
    painter = QPainter(jeu)
    painter.drawPixmap(targets["background"], images["background"], sources["background"])
    painter.drawPixmap(targets["player"], images["player"], sources["player"])

def movement(event : QKeyEvent) -> None :
    """Interprète les évènements provoqués par l'utilisateur sur la zone de jeu et change
    les la position du joueur et du fond en conséquence.

    Args :
        event (QKeyEvent) : L'évènement provoqué par l'utilisateur
    """
    action = MOVES.get(event.key(), False)
    if action :
        if can_move_to((player_pos[0] + action[0], player_pos[1] + action[1])) :
            player_pos[0] += action[0]
            player_pos[1] += action[1]
            viewport = (VIEWPORT_WIDTH, VIEWPORT_HEIGHT)
            background_position[0] = player_pos[0] // viewport[0]
            background_position[1] = player_pos[1] // viewport[1]

def niveau_demande() -> int:
    """Rencoie le niveau se trouvant sur la case sur laquelle est le joueur
    
    Returns :
        int : Le niveau lié à la case sur laquelle se trouve le joueur
    """
    return RESTRICTED_TILES[player_pos[0]][player_pos[1]]

def trigger_niveau(event : QKeyEvent, interface : dict) -> None:
    """Quand l'utilisateur appuie sur la touche entrée, le niveau de la case
    sur laquelle il se trouve est lancé

    Args :
        event (QKeyEvent) : L'évènement provoqué l'utilisateur
        interface (dict) : Le dictionnaire contenant tous les éléments de l'interface
    """
    if event.key() == Qt.Key_Return :
        niveau = niveau_demande()
        if niveau :
            changement_niveau(niveau, interface)

def action_utilisateur(event : QKeyEvent, interface : dict) -> None :
    """Toutes les touches pressées par l'utilisateur passent par cette fonction
    et ces évènements sont redirigés vers le bon élément de l'interface en fonction
    du focus.

    Args :
        event (QKeyEvent) : L'évènement provoqué par l'utilisateur c'est à dire la touche qui a été préssée
        interface (dict) : Le dictionnaire contenant tous les éléments de l'interface
    """
    if interface["zone_texte"].hasFocus() :
        interface["zone_texte"].keyPressEvent(event)
    else :
        movement(event)
        interface["jeu"].update()
        trigger_niveau(event, interface)


def creer_liens(interface : dict) -> None:
    """Lie des évènements à des actions spécifiques.

    Args :
        interface (dict) : Le dictionnaire contenant tous les éléments de l'interface
    """
    interface["fenêtre"].keyPressEvent = lambda event: action_utilisateur(event, interface)
    images = {"background" : QPixmap(r'background.png'), "player" : QPixmap(r'player2.png')}
    interface["jeu"].paintEvent = lambda event : redessiner(interface["jeu"], images)
    interface["bouton_lancer"].clicked.connect(lambda : executer(interface["zone_texte"]))


def main() :
    """La fonction principale"""
    interface = creer_interface()
    creer_liens(interface)
    interface["pile"].showFullScreen()
    interface["application"].exec_()

main()