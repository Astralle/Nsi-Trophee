"""Toutes les fonctions ayant un lien avec l'interface."""
from PyQt5.QtWidgets import QTextEdit, QStackedWidget
from PyQt5.QtGui import QTextCharFormat, QFont, QKeyEvent
from PyQt5.QtCore import Qt
from constantes import *
from fonctions_globales import *

targets = {}
sources = {}

def indenter(zone_texte : QTextEdit, texte : str) -> None:
    """Ajoute une indentation dans l'éditeur de texte du jeu lorsqu'il le faut.

    Args:
        zone_texte (QTextEdit): La zone de texte
        texte (str): Le texte de la zone de texte
    """
    curseur = zone_texte.textCursor()
    i = curseur.position() - 2
    while is_exist(texte, i, ' '):
        i -= 1
    if is_exist(texte, i, ":"):
        curseur.insertText('\t')
    lignes = texte.split('\n')
    curseur.insertText('\t' * lignes[curseur.blockNumber() - 1].count('\t'))

def colorer(zone_texte : QTextEdit, texte: str) -> None:
    """Colore les mots clés d'un texte en fonction de HIGHLIGHTING_RULES

    Args:
        texte (str): Le texte que l'utilisateur a écrit
    """
    curseur = zone_texte.textCursor()
    curseur.setPosition(0)
    curseur.movePosition(curseur.Right, curseur.KeepAnchor, len(zone_texte.toPlainText()))
    char_format = QTextCharFormat()
    char_format.setForeground(Qt.black)
    char_format.setFontWeight(QFont.Normal)
    curseur.mergeCharFormat(char_format)
    for expression, couleur, epaisseur in HIGHLIGHTING_RULES :
        index = expression.indexIn(texte)
        while index != -1:
            length = expression.matchedLength()
            curseur.setPosition(index)
            curseur.movePosition(curseur.Right, curseur.KeepAnchor, length)
            char_format = QTextCharFormat()
            if epaisseur :
                char_format.setFontWeight(QFont.Bold)
            char_format.setForeground(COULEURS[couleur]) 
            curseur.mergeCharFormat(char_format)
            index = expression.indexIn(texte, index + length)

def autocompletion(event : QKeyEvent, zone_texte : QTextEdit) :
    """Complète automatiquement les parenthèses, les crochets, les accolades et les guillemets
    quand celui de gauche est ajouté.

    Args :
        event
    """
    cle = event.key()
    curseur = zone_texte.textCursor()
    ajout = False
    if not event.text().isdigit() :
        if cle == Qt.Key_ParenLeft :
            curseur.insertText(')')
            ajout = True
        elif cle == Qt.Key_BracketLeft :
            curseur.insertText(']')
            ajout = True
        elif cle == Qt.Key_BraceLeft :
            curseur.insertText('}')
            ajout = True
        elif cle == Qt.Key_QuoteDbl :
            curseur.insertText('"')
            ajout = True
        elif cle == Qt.Key_Apostrophe :
            curseur.insertText("'")
            ajout = True
    if ajout :
        curseur = zone_texte.textCursor()
        curseur.setPosition(curseur.position() - 1)
        zone_texte.setTextCursor(curseur)

def text_modifier(zone_texte: QTextEdit, event) -> None:
    """Est appelé quand le texte est modifié.
    Écrit ce que l'utilisateur tappe sur le clavier, ajoute l'indentation et la coloration et autocomplète.

    Args:
        zone_texte (QTextEdit): _description_
        event (_type_): _description_
    """
    zone_texte.super_keyPressEvent(event)
    if not (event.key() == 16777219): # Ne s'applique pas lorsque l'on efface
        texte = zone_texte.toPlainText()
        curseur = zone_texte.textCursor()
        if is_exist(texte, curseur.position() - 1, "\n", " "):
            colorer(zone_texte, texte)
        if is_exist(texte, curseur.position() - 1, "\n"):
            indenter(zone_texte, texte)
        autocompletion(event, zone_texte)

def niveau_actuel(pile_niveaux : QStackedWidget) -> int :
    """Renvoie le numéro du niveau actuel.
    Attention : le premier niveau est 1 et non 0.

    Args :
        pile_niveaux (QStackedWidget) : La pile contenant les niveaux
    
    Returns :
        int : Le niveau actuellement en cours
    """
    return pile_niveaux.currentIndex() + 1

def changement_niveau(niveau : int, interface : dict) -> None :
    """Change le niveau.
    Attention : le premier niveau est 1 et non 0.

    Args :
        niveau (int) : Le niveau demandé
        interface (dict) : Le dictionnaire contenant tous les éléments de l'interface
    """
    interface["pile_niveaux"].setCurrentIndex(niveau - 1)