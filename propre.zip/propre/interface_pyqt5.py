from PyQt5.QtWidgets import QLabel, QPushButton, QVBoxLayout, QWidget, QApplication, QTextEdit, QHBoxLayout, QProgressBar, QStackedWidget, QFrame, QDesktopWidget
from PyQt5.QtGui import QPalette, QColor, QFont, QPixmap, QIcon, QFontMetrics
from PyQt5.QtCore import Qt,  QSize
from constantes import *
from fonctions_liens import text_modifier
from math import ceil

def creer_niveaux() -> tuple[QVBoxLayout, QStackedWidget]:
    conteneur = QHBoxLayout()
    pile_niveaux = QStackedWidget()
    font = QFont()
    font.setPointSize(TAILLE_POLICE)
    pile_niveaux.setFixedHeight(QFontMetrics(font).lineSpacing() * N_LIGNES)
    with open(FICHIER_NIVEAUX, encoding="utf-8") as fichier:
        texte = ""
        n_lignes = 0
        pile_pages = QStackedWidget()
        for ligne in fichier.readlines():
            if ligne == "\n" :
                pile_pages.addWidget(QLabel(texte))
                pile_niveaux.addWidget(pile_pages)
                texte = ""
                n_lignes = 0
                pile_pages = QStackedWidget()
            elif n_lignes >= 10 :
                pile_pages.addWidget(QLabel(texte))
                n_lignes = 0
                texte = ""
            else :
                texte += ligne
                n_lignes += 1
    if texte :
        pile_pages.addWidget(QLabel(texte))
        pile_niveaux.addWidget(pile_pages)
    bouton_precedent = QPushButton("<")
    bouton_precedent.clicked.connect(lambda : pile_niveaux.currentWidget().setCurrentIndex(pile_niveaux.currentWidget().currentIndex() - 1))
    bouton_suivant = QPushButton(">")
    bouton_suivant.clicked.connect(lambda : pile_niveaux.currentWidget().setCurrentIndex(pile_niveaux.currentWidget().currentIndex() + 1))
    conteneur.addWidget(bouton_precedent)
    conteneur.addWidget(pile_niveaux)
    conteneur.addWidget(bouton_suivant)
    return conteneur, pile_niveaux

def creer_zone_texte() -> QTextEdit :
    zone_texte = QTextEdit()
    zone_texte.setTabStopWidth(25)
    zone_texte.super_keyPressEvent = zone_texte.keyPressEvent # La méthode keyPressEvent est enregistré dans la méthode super_keyPressEvent
    zone_texte.keyPressEvent = lambda event : text_modifier(zone_texte, event)
    return zone_texte

def creer_bouton_lancer(barre_cote : QVBoxLayout) -> QPushButton :
    bouton = QPushButton("Lancer")
    style_sheet = "background-color : rgb(0,255,0); border-radius : 15%;"
    bouton.setStyleSheet(style_sheet)
    style_sheet_presse = "background-color : rgb(0,255,0); border-radius : 15%; border : 2px solid black;"
    bouton.pressed.connect(lambda : bouton.setStyleSheet(style_sheet_presse))
    bouton.released.connect(lambda : bouton.setStyleSheet(style_sheet))
    font = QFont()
    font.setPointSize(TAILLE_POLICE)
    bouton.setFont(font)
    bouton.setFixedSize(QSize(bouton.fontMetrics().width("Lancer") + 50, bouton.fontMetrics().height() + 20))
    conteneur = QHBoxLayout()
    conteneur.addStretch()
    conteneur.addWidget(bouton)
    conteneur.addStretch()
    barre_cote.addLayout(conteneur)
    return bouton

def creer_barre_cote(interface : dict) -> tuple[QVBoxLayout, QTextEdit, QStackedWidget, QPushButton] :
    barre = QVBoxLayout()
    bouton_quitter = QPushButton('Fermer')
    barre.addWidget(bouton_quitter)
    bouton_quitter.clicked.connect(interface["application"].quit)
    conteneur, niveaux = creer_niveaux()
    barre.addLayout(conteneur)
    zone_texte = creer_zone_texte()
    barre.addWidget(zone_texte)
    bouton_lancer = creer_bouton_lancer(barre)
    return barre, zone_texte, niveaux, bouton_lancer

def aller_codex(pile_principale : QStackedWidget) :
    if pile_principale.count() == 1 :
        creer_codex(pile_principale)
    pile_principale.setCurrentIndex(1)

def creer_stats(pile_principale : QStackedWidget) -> QHBoxLayout:
    stats = QHBoxLayout()
    label_vie = QLabel("Vie : ")
    vie = QWidget()
    vie_layout = QHBoxLayout()
    barre_vie = QProgressBar()
    barre_vie.setMaximum(VIE_MAX)
    barre_vie.setValue(VIE_MAX)
    vie_layout.addWidget(label_vie)
    vie_layout.addWidget(barre_vie)
    vie.setFixedWidth(VIE_MAX + label_vie.width())
    vie.setLayout(vie_layout)
    stats.addWidget(vie)
    mana = QLabel(f"Mana : {MANA}")
    stats.addWidget(mana)
    bouton_codex = QPushButton()
    bouton_codex.setFixedSize(200, 200)
    bouton_codex.setIconSize(QSize(200,200))
    icon = QIcon(QPixmap("icon_livre.png"))
    bouton_codex.setIcon(icon)
    bouton_codex.clicked.connect(lambda : aller_codex(pile_principale))
    stats.addWidget(bouton_codex)
    return stats

def creer_barre_jeu(interface) :
    barre = QVBoxLayout()
    jeu = QWidget()
    barre.addWidget(jeu)
    stats = creer_stats(interface["pile"])
    barre.addLayout(stats)
    return barre, jeu

def creer_fenetre(interface : dict) -> QWidget :
    fenetre = QWidget()
    fenetre.setFocusPolicy(Qt.StrongFocus)
    font = QFont()
    font.setPointSize(TAILLE_POLICE)
    fenetre.setFont(font)
    return fenetre

def creer_layout(interface : dict) :
    """Renvoie le layout global de la fenêtre principale

    Args :
        interface (dict) :
    """
    layout = QHBoxLayout()
    layout.addLayout(interface["barre_jeu"])
    layout.addLayout(interface["barre_côté"])
    layout.setStretchFactor(interface["barre_jeu"], 3)
    layout.setStretchFactor(interface["barre_côté"], 2)
    return layout

def creer_pages_codex(gauche : QStackedWidget, droite : QStackedWidget, pile : QStackedWidget) :
    hauteur = pile.height() - 100
    n_lignes_affichables = hauteur // QFontMetrics(pile.font()).lineSpacing()
    with open(FICHIER_CODEX, 'r', encoding='utf-8') as fichier :
        lignes = fichier.readlines()
        for n in range(ceil(len(lignes)/n_lignes_affichables)) :
            if not n % 2 :
                gauche.addWidget(QLabel("".join(lignes[n*n_lignes_affichables : min(n_lignes_affichables * (n+1), len(lignes))])))
            else :
                droite.addWidget(QLabel("".join(lignes[n*n_lignes_affichables : min(n_lignes_affichables * (n+1), len(lignes))])))
    if gauche.count() != droite.count() :
        droite.addWidget(QLabel())
    pass

def aller_page(page_gauche : QStackedWidget, page_droite : QStackedWidget, changement : int) -> None :
    page_gauche.setCurrentIndex(page_gauche.currentIndex() + changement)
    page_droite.setCurrentIndex(page_droite.currentIndex() + changement)

def creer_codex(pile_principale : QStackedWidget) -> QWidget :
    """Crée la page du codex
    Args :
        pile_principale (QStackedWidget) : La pile qui contiendra le codex
    """
    codex = QWidget()
    pile_principale.addWidget(codex)
    layout = QVBoxLayout()
    codex.setLayout(layout)
    bouton_retour = QPushButton('Retour')
    bouton_retour.clicked.connect(lambda : pile_principale.setCurrentIndex(0))
    layout.addWidget(bouton_retour)
    sous_layout = QHBoxLayout()
    layout.addLayout(sous_layout)
    bouton_precedent = QPushButton("<")
    page_gauche = QStackedWidget()
    page_droite = QStackedWidget()
    creer_pages_codex(page_gauche, page_droite, pile_principale)
    bouton_suivant =  QPushButton(">")
    bouton_precedent.clicked.connect(lambda : aller_page(page_gauche, page_droite, -1))
    bouton_suivant.clicked.connect(lambda : aller_page(page_gauche, page_droite, +1))
    sous_layout.addWidget(bouton_precedent)
    sous_layout.addWidget(page_gauche)
    sous_layout.addWidget(page_droite)
    sous_layout.addWidget(bouton_suivant)
    return codex

def creer_pile(interface) :
    pile = QStackedWidget()
    palette = QPalette()
    palette.setColor(QPalette.Active, QPalette.Window, QColor(40,41,45))
    palette.setColor(QPalette.Active, QPalette.WindowText, Qt.white)
    pile.setPalette(palette)
    pile.addWidget(interface["fenêtre"])
    return pile

def creer_interface() -> dict:
    interface = {}
    interface["application"] = QApplication([])
    interface["fenêtre"] = creer_fenetre(interface)
    interface["pile"] = creer_pile(interface)
    interface["barre_jeu"], interface["jeu"] = creer_barre_jeu(interface)
    interface["barre_côté"], interface["zone_texte"], interface["pile_niveaux"], interface["bouton_lancer"] = creer_barre_cote(interface)
    interface["layout"] = creer_layout(interface)
    interface["fenêtre"].setLayout(interface["layout"])
    return interface